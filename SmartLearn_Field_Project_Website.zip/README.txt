# SmartLearn — Field Project Website

A responsive, single-page website for the field project **Use of Smartphones for Educational Purposes**.

## Preview locally
Open `index.html` in a browser.

## Publish with GitHub Pages
1. Create or open a GitHub repository.
2. Upload `index.html` to the repository root.
3. Open **Settings → Pages**.
4. Under Build and deployment, choose **Deploy from a branch**.
5. Select `main` and `/(root)`, then Save.
6. Wait for GitHub Pages to publish the site.

## Notes
- The team section uses the names provided: Bhavesh Chaudhari (Team Leader), Rohit Wankhade, Om Saindane, and Rohan Thorat.
- No date, college name, guide name, or survey findings were invented.
- The site labels its research questions and methodology as planned study content, not completed results.
- Edit the text directly in `index.html` if your guide asks for changes.
